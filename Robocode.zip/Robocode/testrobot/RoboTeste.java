package testrobot;
import robocode.*;

import robocode.HitByBulletEvent;
import robocode.Robot;
import robocode.ScannedRobotEvent;
import static robocode.util.Utils.normalRelativeAngleDegrees;

import java.awt.*;

/**
 * RoboTeste - a robot by (Chris_Zerotani)
 */
public class RoboTeste extends Robot
{
	/**
	 * run: RoboTeste's default behavior
	 */
	int dist = 50; // distancia para se mover ao ser atingido

	public void run() {
		// Initialization of the robot should be put here

		// After trying out your robot, try uncommenting the import at the top,
		// and the next line:

		// setColors(Color.red,Color.blue,Color.green); // body,gun,radar
		setBodyColor(Color.green);
		setGunColor(Color.blue);
		setRadarColor(Color.yellow);
		
		// Girar canhão sem parar
		while (true) {
			turnGunRight(5);
		}

	}

	/**
	 * onScannedRobot: Atirar se o robo tiver muita energia
	 */
	public void onScannedRobot(ScannedRobotEvent e) {

		if (e.getDistance() < 50 && getEnergy() > 50) {
			fire(3);
		}
		else {
			fire(1);
		}
		scan();
	}

	/**
	 * onHitByBullet: virar perpendicularmente ao tiro e mover.
	 */
	public void onHitByBullet(HitByBulletEvent e) {

		turnRight(normalRelativeAngleDegrees(90 - (getHeading() - e.getHeading())));

		ahead(dist);
		dist *= -1;
		scan();
	}
	
	/**
	 * onHitWall: Voltar um pouco
	 */
	public void onHitWall(HitWallEvent e) {
		TurnLeft(10)
		ahead(20);
	}	
}
